public class MainGame {
    public static void main(String[] args) {
        // Initialize the GUI and start the game
        new MinesweeperGUI();
    }
}
